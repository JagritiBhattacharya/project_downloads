import configparser
import psycopg2
from sql_queries import create_table_queries, drop_table_queries


def drop_tables(cur, conn):
    '''
    Executes all queries to drop table
    :param cur:  cursor to database
    :param conn: connection object to database
    :return: None
    '''
    for query in drop_table_queries:
        print(query)
        cur.execute(query)
        conn.commit()
    print("Delete success")


def create_tables(cur, conn):

    '''
    Executes all queries to create table
    :param cur:  cursor to database
    :param conn: connection object to database
    :return: None
    '''

    for query in create_table_queries:
        print(query)
        cur.execute(query)
        conn.commit()
    print("Create success")


def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    connection_string = "host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values())
    print(connection_string)

    conn = psycopg2.connect(connection_string)
    cur = conn.cursor()

    drop_tables(cur, conn)
    create_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()