import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


def load_staging_tables(cur, conn):

    '''
    Load staging data from S3 to Redshift tables
    :param cur:  cursor to database
    :param conn: connection object to database
    :return: None
    '''

    for query in copy_table_queries:
        print(query)
        cur.execute(query)
        conn.commit()


def insert_tables(cur, conn):
    '''
    Inserting data from S3 staging tables to Redshift

    :param cur:  cursor to database
    :param conn: connection object to database
    :return: None
    '''
    for query in insert_table_queries:
        print(query)
        cur.execute(query)
        conn.commit()


def main():
    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn_string = "host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values())

    conn = psycopg2.connect(conn_string)
    cur = conn.cursor()
    
    load_staging_tables(cur, conn)
    insert_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()