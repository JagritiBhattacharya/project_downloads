import time
import psycopg2
import boto3
import json


class AWS_Manager():

    def __init__(self):
        self.read_config()
        self.time_limit = 120

    def execute(self):
        self.set_key_secret()
        self.set_parameters()

        self.set_iam()
        self.set_iam_role_arn()

        self.set_ec2()
        self.set_s3()
        self.set_redshift()

        self.set_redshift_cluster()
        self.validate_connection()
        self.delete_cluster()
        self.detach_policies()

    def read_config(self):
        import configparser
        config = configparser.ConfigParser()
        config.read_file(open('dwh.cfg'))
        self.config = config
        self.set_key_secret()

    def set_key_secret(self):
        self.KEY = self.config.get('AWS', 'KEY')
        self.SECRET = self.config.get('AWS', 'SECRET')

    def set_parameters(self):
        config = self.config
        self.DWH_CLUSTER_TYPE = config.get("DWH", "DWH_CLUSTER_TYPE")
        self.DWH_NUM_NODES = config.get("DWH", "DWH_NUM_NODES")
        self.DWH_NODE_TYPE = config.get("DWH", "DWH_NODE_TYPE")

        self.DWH_CLUSTER_IDENTIFIER = config.get("DWH", "DWH_CLUSTER_IDENTIFIER")
        self.DWH_DB = config.get("DWH", "DWH_DB")
        self.DWH_DB_USER = config.get("DWH", "DWH_DB_USER")
        self.DWH_DB_PASSWORD = config.get("DWH", "DWH_DB_PASSWORD")
        self.DWH_PORT = config.get("DWH", "DWH_PORT")

        self.DWH_IAM_ROLE_NAME = config.get("DWH", "DWH_IAM_ROLE_NAME")

        self.IAM_ROLE_ARN = config.get("IAM_ROLE", "ARN")

        self.SONG_DATA_PATH = config.get("S3", "SONG_DATA")
        self.LOG_DATA_PATH = config.get("S3", "LOG_DATA")

    def set_ec2(self):
        self.ec2 = boto3.resource('ec2',
                                  region_name="us-west-2",
                                  aws_access_key_id=self.KEY,
                                  aws_secret_access_key=self.SECRET
                                  )

    def set_s3(self):
        self.s3 = boto3.resource('s3',
                                 region_name="us-west-2",
                                 aws_access_key_id=self.KEY,
                                 aws_secret_access_key=self.SECRET
                                 )

    def set_redshift(self):
        self.redshift = boto3.client('redshift',
                                     region_name="us-west-2",
                                     aws_access_key_id=self.KEY,
                                     aws_secret_access_key=self.SECRET
                                     )

    def set_iam(self):
        self.iam = boto3.client('iam', aws_access_key_id=self.KEY,
                                aws_secret_access_key=self.SECRET,
                                region_name='us-west-2'
                                )

    def set_iam_role_arn(self):
        self.detach_policies()
        try:
            print("1.1 Creating a new IAM Role")
            self.dwhRole = self.iam.create_role(
                Path='/',
                RoleName=self.DWH_IAM_ROLE_NAME,
                Description="Allows Redshift clusters to call AWS services on your behalf.",
                AssumeRolePolicyDocument=json.dumps(
                    {'Statement': [{'Action': 'sts:AssumeRole',
                                    'Effect': 'Allow',
                                    'Principal': {'Service': 'redshift.amazonaws.com'}}],
                     'Version': '2012-10-17'})
            )
        except Exception as e:
            print(e)

        self.iam.attach_role_policy(RoleName=self.DWH_IAM_ROLE_NAME,
                                    PolicyArn="arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"
                                    )
        self.roleArn = self.iam.get_role(RoleName=self.DWH_IAM_ROLE_NAME)['Role']['Arn']

    def set_redshift_cluster(self):
        keys, props = self.get_props()
        if keys is None:
            try:
                response = self.redshift.create_cluster(
                    # HW
                    ClusterType=self.DWH_CLUSTER_TYPE,
                    NodeType=self.DWH_NODE_TYPE,
                    NumberOfNodes=int(self.DWH_NUM_NODES),

                    # Identifiers & Credentials
                    DBName=self.DWH_DB,
                    ClusterIdentifier=self.DWH_CLUSTER_IDENTIFIER,
                    MasterUsername=self.DWH_DB_USER,
                    MasterUserPassword=self.DWH_DB_PASSWORD,

                    # Roles (for s3 access)
                    IamRoles=[self.roleArn]
                )
            except Exception as e:
                print(e)

        keysToShow, data = self.get_props()
        time_taken = 0
        while data and data[keysToShow[2]] != 'available':
            keysToShow, data = self.get_props()
            print("waiting for redshift cluster to be created .... time = {}".format(time_taken))
            time_taken += self.time_limit
            time.sleep(self.time_limit)

        self.DWH_ENDPOINT = self.myClusterProps['Endpoint']['Address']
        self.DWH_ROLE_ARN = self.myClusterProps['IamRoles'][0]['IamRoleArn']
        print("DWH ENDPOINT :: {}".format(self.DWH_ENDPOINT))
        print("DWH ROLE ARN :: {}".format(self.DWH_ROLE_ARN))

        self.open_tcp_port()

    def get_props(self):
        try:
            self.myClusterProps = self.redshift.describe_clusters(
                ClusterIdentifier=self.DWH_CLUSTER_IDENTIFIER)['Clusters'][0]

            keysToShow = ["ClusterIdentifier", "NodeType", "ClusterStatus", "MasterUsername", "DBName", "Endpoint",
                          "NumberOfNodes", 'VpcId']
            data = {k: v for k, v in self.myClusterProps.items() if k in keysToShow}
            return keysToShow, data
        except Exception as e:
            print(e)
            print("Nothing in Redshift perhaps the cluster has been deleted")
            return None, None

    def open_tcp_port(self):
        try:
            vpc = self.ec2.Vpc(id=self.myClusterProps['VpcId'])
            defaultSg = list(vpc.security_groups.all())[0]
            defaultSg.authorize_ingress(
                GroupName=defaultSg.group_name,
                CidrIp='0.0.0.0/0',
                IpProtocol='TCP',
                FromPort=int(self.DWH_PORT),
                ToPort=int(self.DWH_PORT)
            )
        except Exception as e:
            print(e)

    def validate_connection(self):
        try:
            connection_string = "host={} dbname={} user={} password={} port={}".format(*self.config['CLUSTER'].values())
            print(connection_string)

            conn = psycopg2.connect(connection_string)
            cur = conn.cursor()
            print("Got a valid connection")
            return cur, conn
        except Exception as e:
            raise e

    def delete_cluster(self):
        keysToShow, data = self.get_props()
        if keysToShow is not None:
            self.redshift.delete_cluster(ClusterIdentifier=self.DWH_CLUSTER_IDENTIFIER,
                                         SkipFinalClusterSnapshot=True)

        time_taken = 0
        while data is not None:
            keysToShow, data = self.get_props()
            print('Waiting for redshift cluster to be deleted... time = {}'.format(time_taken))
            time_taken += self.time_limit
            time.sleep(self.time_limit)

    def detach_policies(self):
        try:
            self.iam.detach_role_policy(RoleName=self.DWH_IAM_ROLE_NAME,
                                        PolicyArn="arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess")
            self.iam.delete_role(RoleName=self.DWH_IAM_ROLE_NAME)
        except Exception as e:
            print(e)


if __name__ == '__main__':
    so = AWS_Manager()
    so.execute()
    print("All success")
