# Project Problem Statement
## Introduction
A music streaming startup, Sparkify, has grown their user base and song database and want to move their processes and data onto the cloud. Their data resides in S3, in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

As their data engineer, you are tasked with building an ETL pipeline that extracts their data from S3, stages them in Redshift, and transforms data into a set of dimensional tables for their analytics team to continue finding insights into what songs their users are listening to. You'll be able to test your database and ETL pipeline by running queries given to you by the analytics team from Sparkify and compare your results with their expected results.

## Project Description
In this project, you'll apply what you've learned on data warehouses and AWS to build an ETL pipeline for a database hosted on Redshift. To complete the project, you will need to load data from S3 to staging tables on Redshift and execute SQL statements that create the analytics tables from these staging tables.

# Implementations

## File details
* aws_connection_management.py - AWS Lifecycle management demo 
* create_tables.py - Dropping and creating tables in redshift
* dwh.cfg - Configuration file to run the project
* etl.py - Doing the actual ETL, loading the s3 data to redshift staging tables and loading
* staging table data to warehouse tables
* README.md - Summary of project
* sql_queries.py - Contains all the sql query and other heavy lifting to run the pipeline

## Workflow

0. Use the config to write DWH ENDPOINT and DWH ARN
1. Staging data from S3 to Redshift using  COPY queries
   1. Make sure that the data type is matching and for error 1204 ensure
   having varchar values
   2. Use compupdate off to speed up queries, and also parallel load from
   s3 path with prefix
2. From the staged data shift data in facts and dimensions table using bulk insert
   via subqueries.

## How to run:
0. Make sure the dwh.cfg has DWH Endpoint and DWH ARN populated
1. Run create_tables.py to drop and recreate all the tables
2. Run etl.py to load staging data from s3 to redshift staging tables and 
then from there to the redshift data warehouse table

## Trouble-shooting
0. A good roadmap to think about project solution is as follows
   1. Understanding the flow of creating AWS artifacts like ec2, vpc, s3, iam, redshift clusters etc
   2. Once clear with that, look at DWH_ENDPOINT and DWH ARN variables respectively, understand why you need them
      1. DWH_ENDPOINT: Host address where the database is running
      2. DWH ARN: Required for reading data from S3 tables via redshift clusters
   3. Update dwh.cfg file with these details
   4. Write DDL statements for all tables that are needed to be populated
   5. Good idea is to have staging tables without much database constraints
   6. Write COPY statements for staging workflow
   7. Read about different database data types available in redshift from [here](https://docs.aws.amazon.com/redshift/latest/dg/c_Supported_data_types.html)
   8. Use TEXT datatype alternatives wisely, read about COPY command words like TRUNCATECOLUMNS,BLANKSASNULL,EMPTYASNULL
   9. Test the staging workflow using step 6.[useful](https://stackoverflow.com/questions/37847224/getting-table-information-for-redshift-stl-load-errors-errors)
   10. Write bulk insert using subqueries
   11. Test end to end.
