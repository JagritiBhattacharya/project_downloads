from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 aws_credential_id="",
                 table="",
                 reload=True,
                 create_sql="",
                 delete_sql="",
                 insert_sql="",
                 *args, **kwargs
                 ):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        self.table = table
        self.redshift_conn_id = redshift_conn_id
        self.aws_credential_id = aws_credential_id
        self.create_sql = create_sql
        self.delete_sql = delete_sql 
        self.insert_sql = insert_sql
        self.reload = reload

    def execute(self, context):
        self.log.info('LoadDimensionOperator is now starting')
        redshift_hook = PostgresHook(postgres_conn_id=self.redshift_conn_id)
        
        if self.reload:
            self.log.info("Create table {} if not exists".format(self.table))
            redshift_hook.run(self.create_sql)
            self.log.info("Delete table {} data if exists".format(self.table))
            redshift_hook.run(self.delete_sql)
        
        try:
            self.log.info("Inserting into table {}".format(self.table))
            redshift_hook.run(self.insert_sql)
        except Exception as e:
            raise ValueError(e)
