from airflow.hooks.postgres_hook import PostgresHook
from airflow.contrib.hooks.aws_hook import AwsHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults

class StageToRedshiftOperator(BaseOperator):
    ui_color = '#358140'
    template_fields = ("s3_key",)
    copy_sql = '''
        COPY {}
        FROM '{}'
        ACCESS_KEY_ID '{}'
        SECRET_ACCESS_KEY '{}'
        TRUNCATECOLUMNS  EMPTYASNULL BLANKSASNULL 
        FORMAT AS JSON 'auto';
    '''

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 aws_credential_id="",
                 table="",
                 s3_bucket="",
                 s3_key="",
                 create_sql="",
                 delete_sql="",
                 *args, **kwargs
                 ):

        super(StageToRedshiftOperator, self).__init__(*args, **kwargs)
        self.table = table
        self.redshift_conn_id = redshift_conn_id
        self.aws_credential_id = aws_credential_id
        self.s3_key = s3_key
        self.s3_bucket = s3_bucket
        self.create_sql = create_sql
        self.delete_sql = delete_sql 
        

    def execute(self, context):
        self.log.info('StageToRedshiftOperator now starting')
        
        aws_hook = AwsHook(self.aws_credential_id)
        credentials = aws_hook.get_credentials()
        redshift_hook = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        self.log.info("Create table {} if not exists".format(self.table))
        redshift_hook.run(self.create_sql)
        self.log.info("Delete table {} data if exists".format(self.table))
        redshift_hook.run(self.delete_sql)

        self.log.info("Copying data from S3 to redshift")
        rendered_key = self.s3_key.format(**context)

        s3_path = "s3://{}/{}".format(self.s3_bucket, rendered_key)
        self.log.info("s3 path is deduced as {}".format(s3_path))

        formatted_sql = StageToRedshiftOperator.copy_sql.format(
            self.table,
            s3_path,
            credentials.access_key,
            credentials.secret_key
        )

        redshift_hook.run(formatted_sql)





        
        





